gProject = function(spg, spp,normalized=FALSE){}

gInterpolate = function(spgeom, d,normalized=FALSE){}
